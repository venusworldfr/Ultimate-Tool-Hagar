import os
import fade
import getpass
import random
import ctypes
import string
import requests
import base64
from colorama import Fore, init, Style

ctypes.windll.kernel32.SetConsoleTitleW("Hagar Multi-Tool TM")  # Set the title of the console window

init()  # Initialize colorama

default_color = "\033[38;5;88m"  # Set the default color to a dark red color (similar to #830000)

# ... rest of the code ...

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    
default_menu = fade.purpleblue(r"""
       ╔════════════════════════════════════════════╗
       ║  ██╗  ██╗ █████╗  ██████╗  █████╗ ██████╗  ║═══════╔═════════════╗
   ╔═══║  ██║  ██║██╔══██╗██╔════╝ ██╔══██╗██╔══██╗ ║       ║  [T]  Tool  ║
   ║   ║  ███████║███████║██║  ███╗███████║██████╔╝ ║       ╚═════════════╝
   ║   ║  ██╔══██║██╔══██║██║   ██║██╔══██║██╔══██╗ ║═══════════════════════════╗                           ║
   ║   ║  ██║  ██║██║  ██║╚██████╔╝██║  ██║██║  ██║ ║                           ╚═══╔═══════════════════════╗
   ║   ║  ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ║                               ║                       ║ 
   ║   ╚════════════════════════════════════════════╝                               ║  [i] illegal site     ║
   ╚═╗                                               ╚════╗                         ║                       ║
     ╔═════════════════╗                                  ║                         ╚═══════════════════════╝
     ║    [w] owner    ║                                  ╚════╗                                                
     ╚═════════════════╝                                  ╔═════════════════════╗
                                                          ║_____________________║
                                                          ║    [d] discord !    ║
  |--->                                                   ║                     ║
                                                          ╚═════════════════════╝
""")

print(default_color + default_menu + Style.RESET_ALL)  # Reset the color to default after printing

while True:
    choice = input(default_color + "Enter your choice: " + Style.RESET_ALL)
    if choice.lower() == 't':
        token_formatter_menu = fade.purpleblue("""
            [01]   [Nitro generator]  [08]   [Soon...]           [15]    [Soon...]
            [02]   [Id To Token]      [09]   [Soon...]           [16]    [Soon...]
            [03]   [Soon...]          [10]   [Soon...]           [17]    [Soon...]
            [04]   [Soon...]          [11]   [Soon...]           [18]    [Soon...]
            [05]   [Soon...]          [12]   [Soon...]           [19]    [Soon...]
            [06]   [Soon...]          [13]   [Soon...]           [20]    [Soon...]
            [07]   [Soon...]          [14]   [Soon...]           [21]    [Soon...]
        """)
        print(token_formatter_menu)
        tro_choice = input(default_color + "Enter your choice: " + Style.RESET_ALL)
    if choice.strip() == '1':
            webhook_url = input(default_color + "[+] Enter your webhook URL: " + Style.RESET_ALL)
            def generate_nitro_code():
                nitro_code = ''.join(random.choices(string.ascii_uppercase + string.digits + string.ascii_lowercase, k=16))
                return nitro_code
            
    nitro_choice = input(default_color + "Enter your choice: " + Style.RESET_ALL)
    if nitro_choice.strip() == '2':
            banner_menu = fade.purpleblue("""
 ██▓▓█████▄    ▄▄▄█████▓ ▒█████     ▄▄▄█████▓ ▒█████   ██ ▄█▀▓█████  ███▄    █ 
▓██▒▒██▀ ██▌   ▓  ██▒ ▓▒▒██▒  ██▒   ▓  ██▒ ▓▒▒██▒  ██▒ ██▄█▒ ▓█   ▀  ██ ▀█   █ 
▒██▒░██   █▌   ▒ ▓██░ ▒░▒██░  ██▒   ▒ ▓██░ ▒░▒██░  ██▒▓███▄░ ▒███   ▓██  ▀█ ██▒
░██░░▓█▄   ▌   ░ ▓██▓ ░ ▒██   ██░   ░ ▓██▓ ░ ▒██   ██░▓██ █▄ ▒▓█  ▄ ▓██▒  ▐▌██▒
░██░░▒████▓      ▒██▒ ░ ░ ████▓▒░     ▒██▒ ░ ░ ████▓▒░▒██▒ █▄░▒████▒▒██░   ▓██░
░▓   ▒▒▓  ▒      ▒ ░░   ░ ▒░▒░▒░      ▒ ░░   ░ ▒░▒░▒░ ▒ ▒▒ ▓▒░░ ▒░ ░░ ▒░   ▒ ▒ 
 ▒ ░ ░ ▒  ▒        ░      ░ ▒ ▒░        ░      ░ ▒ ▒░ ░ ░▒ ▒░ ░ ░  ░░ ░░   ░ ▒░
 ▒ ░ ░ ░  ░      ░      ░ ░ ░ ▒       ░      ░ ░ ░ ▒  ░ ░░ ░    ░      ░   ░ ░ 
 ░     ░                    ░ ░                  ░ ░  ░  ░      ░  ░         ░ 
     ░ 
            """)
            print(banner_menu)
            userid = input(" ID DE LA CIBLE --|_idtotoken@tool: ")
            encodedBytes = base64.b64encode(userid.encode("utf-8"))
            encodedStr = str(encodedBytes, "utf-8")
            print(f'\n PREMIERE PARTIE : : {encodedStr}')
